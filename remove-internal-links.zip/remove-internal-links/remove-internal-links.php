<?php
/*
Plugin Name: Remove Internal Links
Description: Remove internal links from WordPress posts or pages
Version: 1.0
Author: aicoder
Author URI: https://seowriting.ai?fp_ref=aicoder
*/

// Add admin menu page
add_action('admin_menu', 'ril_add_admin_menu');
function ril_add_admin_menu() {
    add_options_page('Remove Internal Links', 'Remove Links', 'manage_options', 'remove-internal-links', 'ril_options_page');
}

// Plugin options page
function ril_options_page() {
    // Check user capabilities
    if (!current_user_can('manage_options')) {
        return;
    }

    // Handle form submission
    if (isset($_POST['ril_remove_links']) && isset($_POST['ril_nonce']) && wp_verify_nonce($_POST['ril_nonce'], 'ril_remove_links_nonce')) {
        ril_process_link_removal();
    }
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Remove Internal Links', 'remove-internal-links'); ?></h1>
        <form method="post">
            <?php wp_nonce_field('ril_remove_links_nonce', 'ril_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php echo esc_html__('Select Post Type', 'remove-internal-links'); ?></th>
                    <td>
                        <select name="ril_post_type">
                            <option value="post"<?php selected(esc_attr($_POST['ril_post_type'] ?? ''), 'post'); ?>><?php echo esc_html__('Posts', 'remove-internal-links'); ?></option>
                            <option value="page"<?php selected(esc_attr($_POST['ril_post_type'] ?? ''), 'page'); ?>><?php echo esc_html__('Pages', 'remove-internal-links'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Select Processing Speed', 'remove-internal-links'); ?></th>
                    <td>
                        <select name="ril_timeout">
                            <option value="10"<?php selected(esc_attr($_POST['ril_timeout'] ?? ''), '10'); ?>><?php echo esc_html__('Fast (10ms)', 'remove-internal-links'); ?></option>
                            <option value="50"<?php selected(esc_attr($_POST['ril_timeout'] ?? '50'), '50'); ?>><?php echo esc_html__('Average (50ms)', 'remove-internal-links'); ?></option>
                            <option value="100"<?php selected(esc_attr($_POST['ril_timeout'] ?? ''), '100'); ?>><?php echo esc_html__('Slow (100ms)', 'remove-internal-links'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Affiliate Link Prefix', 'remove-internal-links'); ?></th>
                    <td>
                        <input type="text" name="ril_affiliate_prefix" value="<?php echo esc_attr($_POST['ril_affiliate_prefix'] ?? ''); ?>" placeholder="<?php echo esc_attr__('e.g., /go/', 'remove-internal-links'); ?>" />
                        <p class="description"><?php echo esc_html__('Enter the prefix used for affiliate links to ignore during the link removal process.', 'remove-internal-links'); ?></p>
                    </td>
                </tr>
            </table>
            <p><strong><?php echo esc_html__('Warning:', 'remove-internal-links'); ?></strong> <?php echo esc_html__('Please backup your database before removing links.', 'remove-internal-links'); ?></p>
            <?php submit_button(__('Remove Links', 'remove-internal-links'), 'primary', 'ril_remove_links'); ?>
        </form>
        <h2><?php echo esc_html__('Plugin Usage', 'remove-internal-links'); ?></h2>
        <ol>
            <li><?php echo esc_html__('Select Posts or Pages to remove internal links from.', 'remove-internal-links'); ?></li>
            <li><?php
                /* translators: %1$s: Opening <b> tag, %2$s: Closing </b> tag */
                echo sprintf(esc_html__('Choose the %1$sProcessing Speed%2$s: "Fast" for high-performance servers, "Average" for most, or "Slow" for shared hosting.', 'remove-internal-links'), '<b>', '</b>');
            ?></li>
            <li><?php echo esc_html__('Enter the prefix used for affiliate links that should be ignored during link removal (e.g., /go/, /recommend/).', 'remove-internal-links'); ?></li>
            <li><?php echo esc_html__('Click the "Remove Links" button to start link removal.', 'remove-internal-links'); ?></li>
            <li><?php echo esc_html__('It could finish quickly or slowly, depending on how many posts/pages, chosen speed and hosting platform. You will be notified.', 'remove-internal-links'); ?></li>
        </ol>
        <p><strong><?php echo esc_html__('Note:', 'remove-internal-links'); ?></strong> <?php
            /* translators: %s: Link to Rankmath SEO plugin */
            echo sprintf(wp_kses(__('Some plugins like <a href="%s" target="_blank">Rankmath SEO</a> are known to drastically slow down the process. Disable them temporarily.', 'remove-internal-links'), array('a' => array('href' => array(), 'target' => array()))), esc_url('https://rankmath.com/?ref=breakdevize'));
        ?></p>
        <h2><?php echo esc_html__('Support the Plugin Developer and Your Projects', 'remove-internal-links'); ?></h2>
        <p style="font-size:15px;"><?php echo esc_html__('Love this plugin? Skip the endless manual work of linking and writing.', 'remove-internal-links'); ?></p>
        <p style="font-size:15px;"><?php echo esc_html__('Grab my go-to tools to fast-track your website projects!', 'remove-internal-links'); ?></p>
        <ul style="list-style-type:disc; font-size:15px; padding-left:20px;">
            <li><?php
                /* translators: %s: Link to SEO Writing AI */
                echo sprintf(wp_kses(__('<a href="%s" target="_blank">Auto write humanized, deep web and helpful content in bulk</a> - Use coupon DEAL25 for 25%% OFF.', 'remove-internal-links'), array('a' => array('href' => array(), 'target' => array()))), esc_url('https://seowriting.ai?fp_ref=aicoder'));
            ?></li>
            <li><?php
                /* translators: %s: Link to Cloudways hosting */
                echo sprintf(wp_kses(__('<a href="%s" target="_blank">Get blazing fast, reliable and managed VPS hosting from Cloudways</a> - Choose Linode for best performance.', 'remove-internal-links'), array('a' => array('href' => array(), 'target' => array()))), esc_url('https://www.cloudways.com/en/?id=1266451'));
            ?></li>
            <li><?php
                /* translators: %s: Link to LinkWhisper */
                echo sprintf(wp_kses(__('<a href="%s" target="_blank">LinkWhisper is my main linking tool</a>', 'remove-internal-links'), array('a' => array('href' => array(), 'target' => array()))), esc_url('https://linkwhisper.com/ref/3493/'));
            ?></li>
            <li><?php
                /* translators: %s: Link to Linksy */
                echo sprintf(wp_kses(__('<a href="%s" target="_blank">Linksy for better AI linking where LinkWhisper shows no suggestions</a> - Use coupon ADM10OFF for 10%% OFF.', 'remove-internal-links'), array('a' => array('href' => array(), 'target' => array()))), esc_url('https://plugli.com/linksy/ref/39/'));
            ?></li>
            <li><?php
                /* translators: %s: Link to Linkboss */
                echo sprintf(wp_kses(__('<a href="%s" target="_blank">Linkboss for easy AI (bulk) silo interlinking</a>', 'remove-internal-links'), array('a' => array('href' => array(), 'target' => array()))), esc_url('https://linkboss.io?fpr=aicoder'));
            ?></li>
        </ul>
        <p style="font-size:15px;"><?php echo esc_html__('Thanks so much for using my affiliate links to get you going. I truly appreciate you guys.', 'remove-internal-links'); ?></p>
    </div>
    <?php
}

// Process link removal
function ril_process_link_removal() {
    // Check user capabilities
    if (!current_user_can('manage_options')) {
        return;
    }

    // Verify nonce
    if (!isset($_POST['ril_nonce']) || !wp_verify_nonce($_POST['ril_nonce'], 'ril_remove_links_nonce')) {
        wp_die(esc_html__('Invalid nonce. Please try again.', 'remove-internal-links'));
    }

    $post_type = sanitize_text_field($_POST['ril_post_type'] ?? '');
    $timeout = absint($_POST['ril_timeout'] ?? 50);
    $affiliate_prefix = sanitize_text_field($_POST['ril_affiliate_prefix'] ?? '');

    if (!in_array($post_type, array('post', 'page'), true)) {
        echo '<div class="notice notice-error"><p>' . esc_html__('Invalid post type selected.', 'remove-internal-links') . '</p></div>';
        return;
    }

    $args = array(
        'post_type' => $post_type,
        'posts_per_page' => -1,
        'post_status' => 'publish',
    );

    $posts = get_posts($args);
    $total_posts = count($posts);

    foreach ($posts as $post) {
        $site_url = site_url();
        if (!empty($affiliate_prefix)) {
            $content = preg_replace('/<a\s[^>]*href=[\'"]('. preg_quote($site_url, '/') .'(?!'. preg_quote($affiliate_prefix, '/') .')[^\'"]+)[\'"].*?>(.*?)<\/a>/i', '$2', $post->post_content);
        } else {
            $content = preg_replace('/<a\s[^>]*href=[\'"]('. preg_quote($site_url, '/') .'[^\'"]+)[\'"].*?>(.*?)<\/a>/i', '$2', $post->post_content);
        }
        wp_update_post(array(
            'ID' => $post->ID,
            'post_content' => $content,
        ));

        // Delay execution based on timeout
        usleep($timeout * 1000);
    }

    /* translators: 1: Number of posts/pages processed, 2: Post type (posts or pages) */
    echo '<div class="notice notice-success"><p>' . sprintf(esc_html__('Internal link removal process completed for %1$d %2$s.', 'remove-internal-links'), absint($total_posts), esc_html($post_type)) . '</p></div>';
}
